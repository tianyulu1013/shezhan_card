/* ==========================================================================
   《舌战》桌游电子版 核心游戏引擎与 AI 逻辑 (App.js)
   (彻底订正：破口大骂 vs 反唇相讥 单元格为 -/-5, 停动)
   (破口大骂造成反唇相讥-5且停动；反唇相讥被破口大骂停动)
   ========================================================================== */

// SVG Art Icons for 6 Cards
const SVG_ICONS = {
  0: `<svg viewBox="0 0 24 24" fill="none" stroke="#9e7539" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`,
  1: `<svg viewBox="0 0 24 24" fill="none" stroke="#52705e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path></svg>`,
  2: `<svg viewBox="0 0 24 24" fill="none" stroke="#9b4942" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path></svg>`,
  3: `<svg viewBox="0 0 24 24" fill="none" stroke="#746279" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,
  4: `<svg viewBox="0 0 24 24" fill="none" stroke="#536f7e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"></path></svg>`,
  5: `<svg viewBox="0 0 24 24" fill="none" stroke="#8a6046" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m8 3 4 8 5-5 5 15H2L8 3z"></path></svg>`
};

const SEALS = { 0: '破', 1: '反', 2: '怒', 3: '静', 4: '水', 5: '虑' };

const CARD_DESCS = {
  0: '⚡ 同牌相撞时双方-10 HP；击穿《破口大骂》（对方-15 HP）；克制《心如止水》《深思熟虑》（对方-10 HP）；被《反唇相讥》反弹（己方-10 HP）。',
  1: '🌿 反弹《一语道破》（对方-10 HP）；被《破口大骂》压制（己方-5 HP且【停动】）；打断《深思熟虑》（阻断对方回收手牌）。',
  2: '🔥 同牌相撞时双方-5 HP且【停动】；压制《反唇相讥》（对方-5 HP且【停动】）；打《沉默是金》（己方0伤，对方-5 HP）；打《深思熟虑》（己方0伤，对方-5 HP且【停动】，但对方依然能回收）；被《一语道破》刺穿（己方-15 HP）；碰《心如止水》（对方+15 HP）。',
  3: '🌈 最稳试探牌。仅被《破口大骂》造成（己方-5 HP，无停动），面对其他所有牌均为 0 伤害。',
  4: '💧 吸收《破口大骂》（己方+15 HP）；碰《一语道破》（己方-10 HP）；碰其他所有牌均（己方+10 HP）。',
  5: '⛰️ 回收除自身外的所有弃牌。碰《破口大骂》（己方-5 HP且【停动】，但依然成功回收手牌）；遭遇《反唇相讥》回收被打断！'
};

const CARDS = [
  { id: 0, name: '一语道破', color: '#9e7539' },
  { id: 1, name: '反唇相讥', color: '#52705e' },
  { id: 2, name: '破口大骂', color: '#9b4942' },
  { id: 3, name: '沉默是金', color: '#746279' },
  { id: 4, name: '心如止水', color: '#536f7e' },
  { id: 5, name: '深思熟虑', color: '#8a6046' }
];

// 100% EXACT MATCHING MATRIX FOR PDF SCREENSHOT:
// Row 3 (破口大骂) Col 2 (反唇相讥): -/-5, 停动 (Red: -, Blue: -5, 停动)
// So P (Row) gets 0 HP & no stun. F (Col) gets -5 HP & STUN!
const MATRIX = [
  // 0: 一语道破 (Y) vs [Y, F, P, C, X, S]
  [
    {A: -10, B: -10, sA: false, sB: false, pA: false, pB: false},
    {A: -10, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B: -15, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B: -10, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B: -10, sA: false, sB: false, pA: false, pB: true }
  ],

  // 1: 反唇相讥 (F) vs [Y, F, P, C, X, S]
  [
    {A:   0, B: -10, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:  -5, B:   0, sA: true,  sB: false, pA: false, pB: false}, // F (A) vs P (B) -> F takes -5 & STUN! P takes 0!
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B: +10, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false}
  ],

  // 2: 破口大骂 (P) vs [Y, F, P, C, X, S]
  [
    {A: -15, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:  -5, sA: false, sB: true,  pA: false, pB: false}, // P (A) vs F (B) -> P takes 0! F takes -5 & STUN!
    {A:  -5, B:  -5, sA: true,  sB: true,  pA: false, pB: false},
    {A:   0, B:  -5, sA: false, sB: false, pA: false, pB: false}, // P vs C -> P: 0, C: -5 (NO STUN)
    {A:   0, B: +15, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:  -5, sA: false, sB: true,  pA: false, pB: true }  // P vs S -> P: 0, S: -5 & STUN & PICKUP!
  ],

  // 3: 沉默是金 (C) vs [Y, F, P, C, X, S]
  [
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:  -5, B:   0, sA: false, sB: false, pA: false, pB: false}, // C vs P -> C: -5 (NO STUN), P: 0
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B: +10, sA: false, sB: false, pA: false, pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: true }
  ],

  // 4: 心如止水 (X) vs [Y, F, P, C, X, S]
  [
    {A: -10, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A: +10, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A: +15, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A: +10, B:   0, sA: false, sB: false, pA: false, pB: false},
    {A: +10, B: +10, sA: false, sB: false, pA: false, pB: false},
    {A: +10, B:   0, sA: false, sB: false, pA: false, pB: true }
  ],

  // 5: 深思熟虑 (S) vs [Y, F, P, C, X, S]
  [
    {A: -10, B:   0, sA: false, sB: false, pA: true,  pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: false, pB: false}, // S vs F -> NO PICKUP
    {A:  -5, B:   0, sA: true,  sB: false, pA: true,  pB: false}, // S vs P -> S: -5 & STUN & PICKUP, P: 0
    {A:   0, B:   0, sA: false, sB: false, pA: true,  pB: false},
    {A:   0, B: +10, sA: false, sB: false, pA: true,  pB: false},
    {A:   0, B:   0, sA: false, sB: false, pA: true,  pB: true }
  ]
];

function describeMatrixEffects(userCardId, aiCardId, cell) {
  const effects = [];

  if (cell.A < 0) effects.push(`你 ${cell.A} HP`);
  if (cell.A > 0) effects.push(`你 +${cell.A} HP`);
  if (cell.B < 0) effects.push(`AI ${cell.B} HP`);
  if (cell.B > 0) effects.push(`AI +${cell.B} HP`);
  if (cell.sA) effects.push('你被【停动】');
  if (cell.sB) effects.push('AI 被【停动】');
  if (cell.pA) effects.push('你回收除本牌外的弃牌');
  if (cell.pB) effects.push('AI 回收除本牌外的弃牌');

  if (userCardId === 5 && aiCardId === 1 && !cell.pA) {
    effects.push('你的捡牌被《反唇相讥》打断');
  }
  if (aiCardId === 5 && userCardId === 1 && !cell.pB) {
    effects.push('AI 的捡牌被《反唇相讥》打断');
  }

  return effects.length
    ? `${effects.join('；')}。`
    : '双方均无伤害、无停动、无捡牌效果。';
}

// Game Engine Class
class ShezhanGame {
  constructor() {
    this.mode = 'competitive';
    this.difficulty = 'master';
    this.turn = 1;
    this.maxHp = 30;
    
    this.userHp = 30;
    this.aiHp = 30;
    
    this.userStunned = false;
    this.aiStunned = false;
    
    this.userHand = [3, 3, 3, 3, 1, 1];
    this.aiHand = [3, 3, 3, 3, 1, 1];
    
    this.userDiscard = [0, 0, 0, 0, 0, 0];
    this.aiDiscard = [0, 0, 0, 0, 0, 0];
    this.userPlayHistory = [];
    this.aiPlayHistory = [];
    this.aiPersonality = 'balanced';
    this.sessionStats = { wins: 0, losses: 0, draws: 0, games: 0 };
    this.resultRecorded = false;
    
    this.isProcessing = false;
    this.gameOver = false;
  }

  init(mode, difficulty) {
    this.mode = mode;
    this.difficulty = difficulty;
    this.turn = 1;
    this.maxHp = (mode === 'competitive') ? 30 : 40;
    this.userHp = this.maxHp;
    this.aiHp = this.maxHp;
    
    let xCount = (mode === 'competitive') ? 1 : 2;
    this.userHand = [3, 3, 3, 3, xCount, 1];
    this.aiHand = [3, 3, 3, 3, xCount, 1];
    
    this.userDiscard = [0, 0, 0, 0, 0, 0];
    this.aiDiscard = [0, 0, 0, 0, 0, 0];
    this.userPlayHistory = [];
    this.aiPlayHistory = [];
    this.aiPersonality = ['balanced', 'aggressive', 'control', 'resource'][Math.floor(Math.random() * 4)];
    this.resultRecorded = false;
    
    this.userStunned = false;
    this.aiStunned = false;
    this.isProcessing = false;
    this.gameOver = false;
  }

  getHandCount(hand) {
    return hand.reduce((a, b) => a + b, 0);
  }

  checkAutoPickup() {
    if (this.getHandCount(this.userHand) === 0) {
      for (let i = 0; i < 6; i++) {
        this.userHand[i] += this.userDiscard[i];
        this.userDiscard[i] = 0;
      }
      return true;
    }
    return false;
  }

  checkAiAutoPickup() {
    if (this.getHandCount(this.aiHand) === 0) {
      for (let i = 0; i < 6; i++) {
        this.aiHand[i] += this.aiDiscard[i];
        this.aiDiscard[i] = 0;
      }
      return true;
    }
    return false;
  }

  getValidCards(hand) {
    return hand.map((count, card) => count > 0 ? card : -1).filter(card => card !== -1);
  }

  getPlayerProbabilities(state, adaptToCurrentMatch = false) {
    const handWeights = state.userHand.map(count => Math.max(0, count));
    const handTotal = handWeights.reduce((sum, value) => sum + value, 0);
    if (handTotal <= 0) return [];

    let probabilities = handWeights.map(weight => weight / handTotal);

    if (adaptToCurrentMatch && this.userPlayHistory.length > 0) {
      const recent = this.userPlayHistory.slice(-5);
      const patternWeights = handWeights.map(() => 0);

      recent.forEach((card, index) => {
        if (card >= 0 && handWeights[card] > 0) {
          patternWeights[card] += 1 + index * 0.45;
        }
      });

      const patternTotal = patternWeights.reduce((sum, value) => sum + value, 0);
      if (patternTotal > 0) {
        // 一次重复倾向就值得警觉；连续出现后迅速提高置信度，
        // 但最多保留 15% 的手牌基准概率，避免 AI 变成机械读牌。
        const patternConfidence = Math.min(0.88, 0.6 + (recent.length - 1) * 0.2);
        probabilities = probabilities.map((baseProbability, card) =>
          baseProbability * (1 - patternConfidence)
          + (patternWeights[card] / patternTotal) * patternConfidence
        );
      }

      if (state.userHp <= state.maxHp * 0.4 && handWeights[4] > 0) {
        probabilities[4] *= 1.3;
      }
    }

    const total = probabilities.reduce((sum, value) => sum + value, 0);
    return probabilities
      .map((probability, card) => ({ card, probability: probability / total }))
      .filter(item => item.probability > 0);
  }

  evaluatePair(state, userCard, aiCard) {
    const cell = MATRIX[userCard][aiCard];
    const nextUserHp = Math.min(state.maxHp, Math.max(0, state.userHp + cell.A));
    const nextAiHp = Math.min(state.maxHp, Math.max(0, state.aiHp + cell.B));
    const userDelta = nextUserHp - state.userHp;
    const aiDelta = nextAiHp - state.aiHp;
    let score = (-userDelta * 1.12) + (aiDelta * 1.0);

    if (nextUserHp <= 0) score += 100;
    if (nextAiHp <= 0) score -= 120;
    if (cell.sA) score += 7;
    if (cell.sB) score -= 8;

    const userRecoverable = state.userDiscard.slice(0, 5).reduce((a, b) => a + b, 0);
    const aiRecoverable = state.aiDiscard.slice(0, 5).reduce((a, b) => a + b, 0);
    if (cell.pA) score -= userRecoverable * 1.1;
    if (cell.pB) score += aiRecoverable * 1.1;
    if (userCard === 5 && aiCard === 1 && !cell.pA) score += userRecoverable * 0.8;
    if (aiCard === 5 && userCard === 1 && !cell.pB) score -= aiRecoverable * 0.8;

    return score;
  }

  simulatePair(state, userCard, aiCard) {
    const cell = MATRIX[userCard][aiCard];
    const next = {
      maxHp: state.maxHp,
      userHp: Math.min(state.maxHp, Math.max(0, state.userHp + cell.A)),
      aiHp: Math.min(state.maxHp, Math.max(0, state.aiHp + cell.B)),
      userStunned: cell.sA,
      aiStunned: cell.sB,
      userHand: [...state.userHand],
      aiHand: [...state.aiHand],
      userDiscard: [...state.userDiscard],
      aiDiscard: [...state.aiDiscard]
    };

    next.userHand[userCard]--;
    next.aiHand[aiCard]--;
    next.userDiscard[userCard]++;
    next.aiDiscard[aiCard]++;

    if (cell.pA) {
      for (let i = 0; i < 5; i++) {
        next.userHand[i] += next.userDiscard[i];
        next.userDiscard[i] = 0;
      }
    }
    if (cell.pB) {
      for (let i = 0; i < 5; i++) {
        next.aiHand[i] += next.aiDiscard[i];
        next.aiDiscard[i] = 0;
      }
    }

    if (this.getHandCount(next.userHand) === 0) {
      for (let i = 0; i < 6; i++) {
        next.userHand[i] += next.userDiscard[i];
        next.userDiscard[i] = 0;
      }
    }
    if (this.getHandCount(next.aiHand) === 0) {
      for (let i = 0; i < 6; i++) {
        next.aiHand[i] += next.aiDiscard[i];
        next.aiDiscard[i] = 0;
      }
    }

    return next;
  }

  evaluateAiSolo(state, aiCard) {
    if (aiCard === 0) {
      const damage = Math.min(10, state.userHp);
      return damage * 1.12 + (state.userHp <= 10 ? 100 : 0);
    }
    if (aiCard === 2) return 7;
    if (aiCard === 4) return Math.min(10, state.maxHp - state.aiHp);
    if (aiCard === 5) return state.aiDiscard.slice(0, 5).reduce((a, b) => a + b, 0) * 1.1;
    return 0;
  }

  evaluateUserSolo(state, userCard) {
    if (userCard === 0) {
      const damage = Math.min(10, state.aiHp);
      return -(damage * 1.12) - (state.aiHp <= 10 ? 120 : 0);
    }
    if (userCard === 2) return -8;
    if (userCard === 4) return -Math.min(10, state.maxHp - state.userHp);
    if (userCard === 5) return -state.userDiscard.slice(0, 5).reduce((a, b) => a + b, 0) * 1.1;
    return 0;
  }

  estimateNextTurn(state) {
    if (state.userHp <= 0 || state.aiHp <= 0) return 0;
    const aiCards = this.getValidCards(state.aiHand);
    const userCards = this.getValidCards(state.userHand);
    if (state.userStunned && state.aiStunned) return 0;
    if (state.userStunned) {
      return aiCards.length ? Math.max(...aiCards.map(card => this.evaluateAiSolo(state, card))) : 0;
    }
    if (state.aiStunned) {
      return userCards.length ? Math.min(...userCards.map(card => this.evaluateUserSolo(state, card))) : 0;
    }

    const playerProbabilities = this.getPlayerProbabilities(state, false);
    if (!aiCards.length || !playerProbabilities.length) return 0;
    return Math.max(...aiCards.map(aiCard =>
      playerProbabilities.reduce(
        (sum, item) => sum + item.probability * this.evaluatePair(state, item.card, aiCard),
        0
      )
    ));
  }

  getPersonalityBonus(card) {
    const profiles = {
      balanced:  [0, 0, 0, 0, 0, 0],
      aggressive:[0.8, 0, 0.5, -0.1, -0.3, -0.2],
      control:   [0, 0.4, 0.9, 0.3, -0.1, 0],
      resource:  [-0.1, 0, -0.2, 0.1, 0.5, 0.9]
    };
    return profiles[this.aiPersonality][card];
  }

  chooseFromScores(cards, scores, temperature) {
    const bestScore = Math.max(...scores);
    const cutoff = this.difficulty === 'master' ? 10 : 16;
    const weighted = scores.map((score, index) => {
      if (bestScore - score > cutoff) return 0;
      const explorationFloor = bestScore - score <= 4 ? 0.08 : 0;
      return Math.exp((score - bestScore) / temperature) + explorationFloor;
    });
    const total = weighted.reduce((a, b) => a + b, 0);
    let roll = Math.random() * total;
    for (let i = 0; i < cards.length; i++) {
      roll -= weighted[i];
      if (roll <= 0) return cards[i];
    }
    return cards[cards.length - 1];
  }

  getOpeningWeights(validCards) {
    const baseWeights = [3, 2.5, 2.5, 2, 0, 0];
    return validCards.map(card =>
      baseWeights[card] > 0
        ? Math.max(0.2, baseWeights[card] + this.getPersonalityBonus(card) * 0.35)
        : 0
    );
  }

  chooseFromWeights(cards, weights) {
    const total = weights.reduce((a, b) => a + b, 0);
    if (total <= 0) return cards[Math.floor(Math.random() * cards.length)];
    let roll = Math.random() * total;
    for (let i = 0; i < cards.length; i++) {
      roll -= weights[i];
      if (roll <= 0) return cards[i];
    }
    return cards[cards.length - 1];
  }

  getAiChoice() {
    const validCards = this.getValidCards(this.aiHand);
    if (validCards.length === 0) return -1;

    if (this.difficulty === 'easy') {
      return validCards[Math.floor(Math.random() * validCards.length)];
    }

    if (this.turn === 1 && !this.userStunned) {
      const openingCards = validCards.filter(card => card <= 3);
      if (openingCards.length > 0) {
        return this.chooseFromWeights(openingCards, this.getOpeningWeights(openingCards));
      }
    }

    const currentState = {
      maxHp: this.maxHp,
      userHp: this.userHp,
      aiHp: this.aiHp,
      userStunned: this.userStunned,
      aiStunned: this.aiStunned,
      userHand: [...this.userHand],
      aiHand: [...this.aiHand],
      userDiscard: [...this.userDiscard],
      aiDiscard: [...this.aiDiscard]
    };

    if (this.userStunned) {
      if (this.userHp <= 10 && this.aiHand[0] > 0) return 0;
      const soloScores = validCards.map(card => this.evaluateAiSolo(currentState, card));
      return this.chooseFromScores(validCards, soloScores, this.difficulty === 'master' ? 2.4 : 5.5);
    }

    const probabilities = this.getPlayerProbabilities(
      currentState,
      this.difficulty === 'master'
    );

    if (this.difficulty === 'master') {
      const guaranteedLethal = validCards.filter(aiCard =>
        probabilities.every(item => {
          const next = this.simulatePair(currentState, item.card, aiCard);
          return next.userHp <= 0 && next.aiHp > 0;
        })
      );
      if (guaranteedLethal.length > 0) {
        return guaranteedLethal[Math.floor(Math.random() * guaranteedLethal.length)];
      }
    }

    const useLookahead = this.difficulty === 'master';
    const lookaheadWeight = this.userPlayHistory.length > 0 ? 0.28 : 0.55;
    const scores = validCards.map(aiCard => {
      let score = probabilities.reduce((sum, item) => {
        const immediate = this.evaluatePair(currentState, item.card, aiCard);
        if (!useLookahead) return sum + item.probability * immediate;
        const next = this.simulatePair(currentState, item.card, aiCard);
        return sum + item.probability * (
          immediate + this.estimateNextTurn(next) * lookaheadWeight
        );
      }, 0);

      if (useLookahead) {
        score += this.getPersonalityBonus(aiCard);
        const recentAi = this.aiPlayHistory.slice(-2);
        if (recentAi[recentAi.length - 1] === aiCard) score -= 0.8;
        if (recentAi.length === 2 && recentAi.every(card => card === aiCard)) score -= 1.2;
      }
      return score;
    });

    return this.chooseFromScores(
      validCards,
      scores,
      this.difficulty === 'master'
        ? (this.userPlayHistory.length >= 2 ? 2.4 : (this.turn <= 3 ? 3.4 : 3.2))
        : 6.5
    );
  }

  recordTurn(userCard, aiCard) {
    if (userCard >= 0) this.userPlayHistory.push(userCard);
    if (aiCard >= 0) this.aiPlayHistory.push(aiCard);
  }

  consumeMutualStunTurn() {
    if (
      !this.userStunned
      || !this.aiStunned
      || this.userHp <= 0
      || this.aiHp <= 0
    ) return false;

    this.userStunned = false;
    this.aiStunned = false;
    this.turn++;
    return true;
  }

  recordGameResult(result) {
    if (this.resultRecorded || !['win', 'loss', 'draw'].includes(result)) return false;
    this.sessionStats.games++;
    if (result === 'win') this.sessionStats.wins++;
    if (result === 'loss') this.sessionStats.losses++;
    if (result === 'draw') this.sessionStats.draws++;
    this.resultRecorded = true;
    return true;
  }

  getSessionWinRate() {
    if (this.sessionStats.games === 0) return null;
    return Math.round((this.sessionStats.wins / this.sessionStats.games) * 100);
  }
}

// UI Controller
document.addEventListener('DOMContentLoaded', () => {
  const game = new ShezhanGame();

  // Cover Screen & Setup Elements
  const coverScreen = document.getElementById('cover-screen');
  const btnEnterGame = document.getElementById('btn-enter-game');
  const btnCoverRules = document.getElementById('btn-cover-rules');

  const trackerModal = document.getElementById('tracker-modal');
  const rulesModal = document.getElementById('rules-modal');
  const gameoverModal = document.getElementById('gameover-modal');
  const sessionWins = document.getElementById('session-wins');
  const sessionLosses = document.getElementById('session-losses');
  const sessionDraws = document.getElementById('session-draws');
  const sessionGames = document.getElementById('session-games');
  const sessionWinRate = document.getElementById('session-win-rate');
  const gameoverSessionRecord = document.getElementById('gameover-session-record');

  const btnTracker = document.getElementById('btn-tracker');
  const btnRules = document.getElementById('btn-rules');
  const btnRestart = document.getElementById('btn-restart');
  const btnPlayAgain = document.getElementById('btn-play-again');

  const userHpBar = document.getElementById('user-hp-bar');
  const userHpText = document.getElementById('user-hp-text');
  const userHandCount = document.getElementById('user-hand-count');
  const userStunBadge = document.getElementById('user-stun-badge');
  const userDiscardPreview = document.getElementById('user-discard-preview');
  const recoverableCount = document.getElementById('recoverable-count');

  const aiHpBar = document.getElementById('ai-hp-bar');
  const aiHpText = document.getElementById('ai-hp-text');
  const aiHandCount = document.getElementById('ai-hand-count');
  const aiStunBadge = document.getElementById('ai-stun-badge');
  const aiDiffTag = document.getElementById('ai-diff-tag');
  const aiHandBacks = document.getElementById('ai-hand-backs');

  const turnCounter = document.getElementById('turn-counter');
  const stunNoticeBanner = document.getElementById('stun-notice-banner');
  const stunNoticeText = document.getElementById('stun-notice-text');
  const arenaZone = document.querySelector('.arena-zone');
  const playerCardSlot = document.getElementById('player-card-slot');
  const aiCardSlot = document.getElementById('ai-card-slot');
  const clashRay = document.getElementById('clash-ray');
  const outcomeBanner = document.getElementById('outcome-banner');
  const outcomeText = document.getElementById('outcome-text');
  const battleLog = document.getElementById('battle-log');
  const handCardsContainer = document.getElementById('hand-cards-container');
  const handActionBar = document.getElementById('hand-action-bar');
  const selectedCardName = document.getElementById('selected-card-name');
  const btnCancelCard = document.getElementById('btn-cancel-card');
  const btnConfirmCard = document.getElementById('btn-confirm-card');

  // Hover Tooltip Elements
  const hoverTooltip = document.getElementById('card-hover-tooltip');
  const tooltipTitle = document.getElementById('tooltip-title');
  const tooltipBody = document.getElementById('tooltip-body');

  let selectedMode = 'casual';
  let selectedDiff = 'master';
  let selectedCardId = null;
  let suppressCardClick = false;

  // Mode & Difficulty Setup in Cover Screen
  document.querySelectorAll('.mode-select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mode-select-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedMode = btn.dataset.mode;
    });
  });

  document.querySelectorAll('.diff-select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.diff-select-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedDiff = btn.dataset.diff;
    });
  });

  btnEnterGame.addEventListener('click', () => {
    game.init(selectedMode, selectedDiff);
    clearCardSelection();
    coverScreen.classList.remove('active');
    resetArenaSlots();
    updateUI();
    addLog(`对局开始！模式：${selectedMode === 'competitive' ? '⚡竞技刺客 (30HP)' : '♟️持久策略 (40HP · 双心如止水)'} | AI难度：${selectedDiff.toUpperCase()}`, 'system');
  });

  btnCoverRules.addEventListener('click', () => {
    rulesModal.classList.add('active');
  });

  btnRestart.addEventListener('click', () => {
    clearCardSelection();
    coverScreen.classList.add('active');
  });

  btnPlayAgain.addEventListener('click', () => {
    clearCardSelection();
    gameoverModal.classList.remove('active');
    coverScreen.classList.add('active');
  });

  btnCancelCard.addEventListener('click', () => clearCardSelection());
  btnConfirmCard.addEventListener('click', () => {
    if (selectedCardId !== null) {
      const sourceCard = handCardsContainer.querySelector(
        `.dock-card-wrapper[data-card-id="${selectedCardId}"]`
      );
      commitCard(selectedCardId, sourceCard);
    }
  });

  btnTracker.addEventListener('click', () => {
    renderTracker();
    trackerModal.classList.add('active');
  });

  btnRules.addEventListener('click', () => {
    rulesModal.classList.add('active');
  });

  document.querySelectorAll('.close-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById(btn.dataset.close).classList.remove('active');
    });
  });

  document.addEventListener('touchstart', (e) => {
    if (!e.target.closest('.dock-card-wrapper')) {
      hideCardTooltip();
    }
  }, { passive: true });

  function clearPlayedCards() {
    playerCardSlot.innerHTML = `<div class="slot-placeholder">等待选牌...</div>`;
    playerCardSlot.classList.remove('drop-ready');
    aiCardSlot.innerHTML = `<div class="slot-placeholder">等待出牌...</div>`;
  }

  function resetArenaSlots() {
    clearPlayedCards();
    outcomeBanner.classList.add('hidden');
    stunNoticeBanner.classList.add('hidden');
    clashRay.classList.add('hidden');
  }

  // Render Card 3D Element (Complete with 3D Flip animation support)
  function createCard3DHtml(cardId, isFaceDown = true) {
    if (cardId === -1) {
      return `<div class="stun-slot-badge">😵 停动跳过<br><small style="font-size:0.75rem;">(SKIPPED)</small></div>`;
    }
    const card = CARDS[cardId];
    return `
      <div class="card-container-3d ${isFaceDown ? '' : 'flipped'}" data-card="${cardId}">
        <div class="card-3d-inner">
          <!-- BACK FACE (Facing user when card is face down) -->
          <div class="card-face card-face-back">
            <div class="card-back-pattern">
              <div class="card-back-seal">舌</div>
              <span class="card-back-text">舌战</span>
            </div>
          </div>
          <!-- FRONT FACE (Facing user when card is flipped 180deg) -->
          <div class="card-face card-face-front">
            <div class="card-header-bar">
              <span class="card-type-icon">${card.name.substring(0, 1)}</span>
              <span class="card-seal-stamp">${SEALS[cardId]}</span>
            </div>
            <div class="card-main-art">
              <div class="art-svg-medallion">
                ${SVG_ICONS[cardId]}
              </div>
            </div>
            <div class="card-title-vertical">${card.name}</div>
          </div>
        </div>
      </div>
    `;
  }

  function syncCardSelectionUI() {
    const hasSelection = selectedCardId !== null;
    const recoverableCards = game.userDiscard.slice(0, 5).reduce((sum, qty) => sum + qty, 0);
    handActionBar.classList.toggle('has-selection', hasSelection);
    selectedCardName.textContent = hasSelection
      ? (
        selectedCardId === 5
          ? `已选：深思熟虑 · 可捡 ${recoverableCards}`
          : `已选：${CARDS[selectedCardId].name}`
      )
      : '点选或上拖';
    btnCancelCard.disabled = !hasSelection;
    btnConfirmCard.disabled = !hasSelection;

    handCardsContainer.querySelectorAll('.dock-card-wrapper').forEach(wrapper => {
      wrapper.classList.toggle(
        'selected',
        hasSelection && Number(wrapper.dataset.cardId) === selectedCardId
      );
    });
  }

  function clearCardSelection() {
    selectedCardId = null;
    playerCardSlot.classList.remove('drop-ready');
    arenaZone.classList.remove('drag-ready');
    syncCardSelectionUI();
  }

  function selectCard(cardId) {
    if (
      game.isProcessing
      || game.gameOver
      || game.userStunned
      || game.userHand[cardId] <= 0
    ) return;

    selectedCardId = cardId;
    syncCardSelectionUI();
  }

  function previewCardRemoval(sourceCard, cardId) {
    const qty = game.userHand[cardId];
    const qtyTag = sourceCard.querySelector('.card-qty-tag');
    sourceCard.classList.add('card-being-played');
    if (qty > 1 && qtyTag) {
      qtyTag.textContent = qty - 1;
    } else {
      if (qtyTag) qtyTag.classList.add('hidden');
      sourceCard.classList.add('last-copy-playing');
    }
  }

  function restoreCardPreview(sourceCard, cardId) {
    const qtyTag = sourceCard.querySelector('.card-qty-tag');
    sourceCard.classList.remove('card-being-played', 'last-copy-playing');
    if (qtyTag) {
      qtyTag.textContent = game.userHand[cardId];
      qtyTag.classList.remove('hidden');
    }
  }

  function createFlyingCard(cardVisual) {
    const startRect = cardVisual.getBoundingClientRect();
    const flyingCard = cardVisual.cloneNode(true);
    flyingCard.classList.add('drag-flight-card');
    Object.assign(flyingCard.style, {
      left: `${startRect.left}px`,
      top: `${startRect.top}px`,
      width: `${startRect.width}px`,
      height: `${startRect.height}px`
    });
    document.body.appendChild(flyingCard);
    return flyingCard;
  }

  function animateCardIntoArena(sourceCard, cardId, existingFlyingCard = null) {
    const cardVisual = sourceCard?.querySelector('.card-container-3d');
    if (!cardVisual) {
      handleTurn(cardId);
      return;
    }

    const flyingCard = existingFlyingCard || createFlyingCard(cardVisual);
    const startRect = flyingCard.getBoundingClientRect();
    const targetRect = playerCardSlot.getBoundingClientRect();
    Object.assign(flyingCard.style, {
      left: `${startRect.left}px`,
      top: `${startRect.top}px`,
      width: `${startRect.width}px`,
      height: `${startRect.height}px`,
      transform: 'none'
    });
    if (!sourceCard.classList.contains('card-being-played')) {
      previewCardRemoval(sourceCard, cardId);
    }
    game.isProcessing = true;

    let finished = false;
    const finishFlight = () => {
      if (finished) return;
      finished = true;
      flyingCard.remove();
      game.isProcessing = false;
      handleTurn(cardId);
    };

    if (typeof flyingCard.animate === 'function') {
      const flight = flyingCard.animate([
        {
          left: `${startRect.left}px`,
          top: `${startRect.top}px`,
          width: `${startRect.width}px`,
          height: `${startRect.height}px`,
          opacity: 1
        },
        {
          left: `${targetRect.left}px`,
          top: `${targetRect.top}px`,
          width: `${targetRect.width}px`,
          height: `${targetRect.height}px`,
          opacity: 0.98
        }
      ], {
        duration: 230,
        easing: 'cubic-bezier(0.2, 0.8, 0.25, 1)',
        fill: 'forwards'
      });
      flight.addEventListener('finish', finishFlight, { once: true });
      flight.addEventListener('cancel', finishFlight, { once: true });
      setTimeout(finishFlight, 270);
    } else {
      setTimeout(finishFlight, 230);
    }
  }

  function commitCard(cardId, sourceCard = null) {
    if (
      game.isProcessing
      || game.gameOver
      || game.userStunned
      || game.userHand[cardId] <= 0
    ) return;

    selectedCardId = cardId;
    if (sourceCard) animateCardIntoArena(sourceCard, cardId);
    else handleTurn(cardId);
  }

  function enableCardDrag(cardWrapper, cardId) {
    let drag = null;
    cardWrapper.draggable = false;

    const moveDrag = (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;

      if (!drag.active && Math.hypot(dx, dy) > 8) {
        drag.active = true;
        hideCardTooltip();
        drag.flyingCard = createFlyingCard(
          cardWrapper.querySelector('.card-container-3d')
        );
        drag.flyingStart = drag.flyingCard.getBoundingClientRect();
        previewCardRemoval(cardWrapper, cardId);
      }
      if (!drag.active) return;

      event.preventDefault();
      Object.assign(drag.flyingCard.style, {
        left: `${drag.flyingStart.left + dx}px`,
        top: `${drag.flyingStart.top + dy}px`
      });
      const playThreshold = Math.min(64, cardWrapper.getBoundingClientRect().height * 0.7);
      drag.canPlay = dy < -playThreshold;
      playerCardSlot.classList.toggle('drop-ready', drag.canPlay);
      arenaZone.classList.toggle('drag-ready', drag.canPlay);
    };

    const finishDrag = (event, cancelled = false) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const shouldPlay = drag.active && drag.canPlay && !cancelled;
      if (drag.active) {
        suppressCardClick = true;
        setTimeout(() => { suppressCardClick = false; }, 0);
      }
      const wasActive = drag.active;
      const flyingCard = drag.flyingCard;
      drag = null;

      if (shouldPlay) {
        animateCardIntoArena(cardWrapper, cardId, flyingCard);
      } else {
        flyingCard?.remove();
        if (wasActive) restoreCardPreview(cardWrapper, cardId);
        if (wasActive && !cancelled) selectCard(cardId);
      }
      playerCardSlot.classList.remove('drop-ready');
      arenaZone.classList.remove('drag-ready');
      window.removeEventListener('pointermove', moveDrag);
      window.removeEventListener('pointerup', finishDrag);
      window.removeEventListener('pointercancel', cancelDrag);
    };

    const cancelDrag = event => finishDrag(event, true);

    cardWrapper.addEventListener('pointerdown', (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      if (game.isProcessing || game.gameOver || game.userStunned) return;
      drag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        active: false,
        canPlay: false
      };
      window.addEventListener('pointermove', moveDrag, { passive: false });
      window.addEventListener('pointerup', finishDrag);
      window.addEventListener('pointercancel', cancelDrag);
    });
  }

  // Render Hand Dock
  function renderHandDock() {
    handCardsContainer.innerHTML = '';
    
    if (game.checkAutoPickup()) {
      addLog('👤 你的手牌已用光，触发【全量自动回收】！全部手牌已重置回到手中。', 'heal');
    }

    if (
      selectedCardId !== null
      && (game.userStunned || game.userHand[selectedCardId] <= 0)
    ) {
      selectedCardId = null;
    }

    CARDS.forEach((card) => {
      const qty = game.userHand[card.id];
      const unavailable = qty === 0 || game.userStunned || game.isProcessing;
      const cardWrapper = document.createElement('div');
      cardWrapper.dataset.cardId = card.id;
      cardWrapper.className =
        `dock-card-wrapper ${unavailable ? 'disabled' : ''} ${selectedCardId === card.id ? 'selected' : ''}`;
      
      cardWrapper.innerHTML = `
        ${createCard3DHtml(card.id, false)}
        ${qty > 0 ? `<span class="card-qty-tag">${qty}</span>` : ''}
      `;

      cardWrapper.addEventListener('mouseenter', (e) => showCardTooltip(card.id, e));
      cardWrapper.addEventListener('mousemove', (e) => positionCardTooltip(e));
      cardWrapper.addEventListener('mouseleave', () => hideCardTooltip());

      if (!unavailable) {
        cardWrapper.addEventListener('click', () => {
          if (suppressCardClick) return;
          hideCardTooltip();
          selectCard(card.id);
        });
        cardWrapper.addEventListener('dblclick', () => {
          if (suppressCardClick) return;
          hideCardTooltip();
          commitCard(card.id, cardWrapper);
        });
        enableCardDrag(cardWrapper, card.id);
      }

      handCardsContainer.appendChild(cardWrapper);
    });

    if (game.userStunned) {
      const stunOverlay = document.createElement('div');
      stunOverlay.className = 'hand-stun-overlay';
      stunOverlay.innerHTML = `
        <span>😵 本回合停动，手牌保持不变</span>
        <button id="btn-skip-turn" class="btn btn-primary" type="button" aria-disabled="false">▶ 继续 · 跳过本回合</button>
      `;
      handCardsContainer.appendChild(stunOverlay);
      stunOverlay.querySelector('#btn-skip-turn')?.addEventListener('click', () => handleTurn(-1));
    }

    syncCardSelectionUI();
  }

  function showCardTooltip(cardId, e) {
    tooltipTitle.textContent = CARDS[cardId].name;
    tooltipBody.textContent = CARD_DESCS[cardId];
    hoverTooltip.classList.remove('hidden');
    positionCardTooltip(e);
  }

  function positionCardTooltip(e) {
    let clientX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : window.innerWidth / 2);
    let clientY = e.clientY || (e.touches && e.touches[0] ? e.touches[0].clientY : window.innerHeight / 2);

    let left = clientX + 15;
    let top = clientY - 80;
    if (left + 250 > window.innerWidth) left = Math.max(10, clientX - 250);
    if (top < 10) top = clientY + 15;
    hoverTooltip.style.left = left + 'px';
    hoverTooltip.style.top = top + 'px';
  }

  function hideCardTooltip() {
    hoverTooltip.classList.add('hidden');
  }

  function renderDiscardPreview() {
    const recoverableCards = game.userDiscard.slice(0, 5).reduce((sum, qty) => sum + qty, 0);
    const discardedCards = CARDS.filter(card => game.userDiscard[card.id] > 0);

    recoverableCount.textContent = `深思可捡 ${recoverableCards} 张`;
    userDiscardPreview.innerHTML = discardedCards.length
      ? discardedCards.map(card => {
        const qty = game.userDiscard[card.id];
        const unrecoverable = card.id === 5;
        const note = unrecoverable ? '（不能被深思熟虑自身回收）' : '';
        return `<span class="discard-chip ${unrecoverable ? 'unrecoverable' : ''}"
          title="${card.name} ×${qty}${note}">${card.name.substring(0, 1)}×${qty}</span>`;
      }).join('')
      : '<span class="discard-empty">空</span>';
  }

  function renderAiHandBacks() {
    aiHandBacks.innerHTML = '';
    let count = game.getHandCount(game.aiHand);
    for (let i = 0; i < Math.min(15, count); i++) {
      const miniBack = document.createElement('div');
      miniBack.className = 'card-back-mini';
      miniBack.textContent = '舌';
      aiHandBacks.appendChild(miniBack);
    }
  }

  function handleTurn(userCardId) {
    if (game.isProcessing || game.gameOver) return;
    clearCardSelection();
    game.isProcessing = true;
    outcomeBanner.classList.add('hidden');

    if (game.checkAiAutoPickup()) {
      addLog('🤖 AI 对手手牌用光，触发【全量自动回收】！', 'system');
    }

    let aiCardId = -1;
    if (!game.aiStunned) {
      aiCardId = game.getAiChoice();
    }

    clashRay.classList.add('hidden');
    
    // Step 1: Render cards face-down into arena slots with card back animation
    playerCardSlot.innerHTML = createCard3DHtml(userCardId, true);
    aiCardSlot.innerHTML = createCard3DHtml(aiCardId, true);

    if (userCardId !== -1) {
      game.userHand[userCardId]--;
      game.userDiscard[userCardId]++;
    }
    if (aiCardId !== -1) {
      game.aiHand[aiCardId]--;
      game.aiDiscard[aiCardId]++;
    }
    game.recordTurn(userCardId, aiCardId);

    renderAiHandBacks();

    // Step 2: After 400ms, trigger simultaneous 3D Flip animation (rotateY(180deg))
    setTimeout(() => {
      document.querySelectorAll('.arena-card-slot .card-container-3d').forEach(el => {
        el.classList.add('flipped');
      });

      // Step 3: After flip finishes (500ms), show energy ray beam and resolve outcome
      setTimeout(() => {
        clashRay.classList.remove('hidden');

        setTimeout(() => {
          clashRay.classList.add('hidden');
          resolveOutcome(userCardId, aiCardId);
          document.querySelectorAll('.arena-card-slot .card-container-3d').forEach(el => {
            el.classList.add('played-card-exit');
          });

          setTimeout(() => {
            clearPlayedCards();
            game.turn++;
            game.isProcessing = false;
            updateUI();
            checkGameOver();
          }, 220);
        }, 500);
      }, 500);
    }, 400);
  }

  function resolveOutcome(uId, aId) {
    let outcomeStr = '';
    
    if (uId !== -1 && aId !== -1) {
      let cell = MATRIX[uId][aId];
      game.userHp += cell.A;
      game.aiHp += cell.B;
      
      game.userStunned = cell.sA;
      game.aiStunned = cell.sB;

      if (cell.pA) {
        for(let k=0; k<5; k++) { game.userHand[k] += game.userDiscard[k]; game.userDiscard[k] = 0; }
        if (aId === 2) {
          addLog('👤 你打出《深思熟虑》遭遇《破口大骂》：虽受到 -5 伤害并被【停动】，但成功回收了全部弃牌！', 'heal');
        } else {
          addLog('👤 你使用了《深思熟虑》，成功回收了已打出的手牌！', 'heal');
        }
      } else if (uId === 5) {
        addLog('⚠️ 你的《深思熟虑》遭遇《反唇相讥》，回收被打断！', 'dmg');
      }

      if (cell.pB) {
        for(let k=0; k<5; k++) { game.aiHand[k] += game.aiDiscard[k]; game.aiDiscard[k] = 0; }
        if (uId === 2) {
          addLog('🤖 AI打出《深思熟虑》遭遇《破口大骂》：虽受到 -5 伤害并被【停动】，但成功回收了全部弃牌！', 'system');
        } else {
          addLog('🤖 AI 使用了《深思熟虑》，成功回收了已打出的手牌！', 'system');
        }
      } else if (aId === 5) {
        addLog('⚠️ AI 的《深思熟虑》遭遇《反唇相讥》，回收被打断！', 'heal');
      }

      outcomeStr = `【对决】你出《${CARDS[uId].name}》，AI 出《${CARDS[aId].name}》。${describeMatrixEffects(uId, aId, cell)}`;

    } else if (uId !== -1 && aId === -1) {
      // 停动时没有对手牌可供结算；破口大骂只续停动，不重复扣血。
      game.aiStunned = false;
      if (uId === 0) {
        game.aiHp -= 10;
        outcomeStr = `AI本轮因【停动】未出牌；你的《一语道破》直接攻击，AI -10 HP。`;
      }
      else if (uId === 2) {
        game.aiStunned = true;
        outcomeStr = `AI本轮因【停动】未出牌；《破口大骂》续接【停动】，但不造成伤害。`;
      }
      else if (uId === 4) { game.userHp += 10; outcomeStr = `AI本轮因【停动】未出牌；你的《心如止水》恢复 +10 HP。`; }
      else if (uId === 5) { 
        for(let k=0; k<5; k++) { game.userHand[k] += game.userDiscard[k]; game.userDiscard[k] = 0; }
        outcomeStr = `AI本轮因【停动】未出牌；你用《深思熟虑》回收了除本牌外的弃牌。`;
      } else { outcomeStr = `AI本轮因【停动】未出牌；《${CARDS[uId].name}》没有对手牌可供结算。`; }

    } else if (uId === -1 && aId !== -1) {
      // 与上面的玩家分支保持完全对称。
      game.userStunned = false;
      if (aId === 0) {
        game.userHp -= 10;
        outcomeStr = `你本轮因【停动】未出牌；AI 的《一语道破》直接攻击，你 -10 HP。`;
      }
      else if (aId === 2) {
        game.userStunned = true;
        outcomeStr = `你本轮因【停动】未出牌；AI 的《破口大骂》续接【停动】，但不造成伤害。`;
      }
      else if (aId === 4) { game.aiHp += 10; outcomeStr = `你本轮因【停动】未出牌；AI 的《心如止水》恢复 +10 HP。`; }
      else if (aId === 5) {
        for(let k=0; k<5; k++) { game.aiHand[k] += game.aiDiscard[k]; game.aiDiscard[k] = 0; }
        outcomeStr = `你本轮因【停动】未出牌；AI 用《深思熟虑》回收了除本牌外的弃牌。`;
      } else { outcomeStr = `你本轮因【停动】未出牌；AI 的《${CARDS[aId].name}》没有对手牌可供结算。`; }

    } else {
      game.userStunned = false;
      game.aiStunned = false;
      outcomeStr = `双方均处于【停动】状态，本回合平稳过档！`;
    }

    game.userHp = Math.min(game.maxHp, Math.max(0, game.userHp));
    game.aiHp = Math.min(game.maxHp, Math.max(0, game.aiHp));

    outcomeBanner.classList.remove('hidden');
    outcomeText.textContent = outcomeStr;
    addLog(outcomeStr, (game.userHp > game.aiHp) ? 'heal' : 'dmg');
  }

  function updateUI() {
    if (game.userStunned && game.aiStunned && game.userHp > 0 && game.aiHp > 0) {
      const skippedTurn = game.turn;
      addLog(`双方均处于【停动】状态，第 ${skippedTurn} 回合已自动跳过。`, 'stun');
      game.consumeMutualStunTurn();
    }

    turnCounter.textContent = `第 ${game.turn} 回合`;
    
    let uPct = (game.userHp / game.maxHp * 100).toFixed(1);
    let aPct = (game.aiHp / game.maxHp * 100).toFixed(1);

    userHpBar.style.width = uPct + '%';
    userHpText.textContent = `${game.userHp}/${game.maxHp}`;

    aiHpBar.style.width = aPct + '%';
    aiHpText.textContent = `${game.aiHp}/${game.maxHp}`;

    userHandCount.textContent = game.getHandCount(game.userHand);
    aiHandCount.textContent = game.getHandCount(game.aiHand);

    if (game.userStunned) userStunBadge.classList.remove('hidden');
    else userStunBadge.classList.add('hidden');

    if (game.aiStunned) aiStunBadge.classList.remove('hidden');
    else aiStunBadge.classList.add('hidden');

    if (game.aiStunned && !game.userStunned) {
      stunNoticeBanner.classList.remove('hidden');
      stunNoticeText.textContent = `😵 提示：AI 处于【停动】状态！本回合无法出牌，你可以单方面自由出牌！`;
    } else if (game.userStunned && !game.aiStunned) {
      stunNoticeBanner.classList.remove('hidden');
      stunNoticeText.textContent = `😵 提示：你处于【停动】状态！本回合无法出牌，请点击跳过回合。`;
    } else if (game.userStunned && game.aiStunned) {
      stunNoticeBanner.classList.remove('hidden');
      stunNoticeText.textContent = `😵 提示：双方均处于【停动】状态！`;
    } else {
      stunNoticeBanner.classList.add('hidden');
    }

    aiDiffTag.textContent = (game.difficulty === 'master') ? '🧠 大师 AI' : (game.difficulty === 'medium' ? '⚖️ 中级 AI' : '🎲 随机 AI');

    renderAiHandBacks();
    renderDiscardPreview();
    renderHandDock();
  }

  function addLog(text, type = 'system') {
    const pEl = document.createElement('p');
    pEl.className = `log-item ${type}`;
    pEl.textContent = `[T${game.turn}] ${text}`;
    battleLog.appendChild(pEl);
    battleLog.scrollTop = battleLog.scrollHeight;
  }

  function renderTracker() {
    const aiList = document.getElementById('ai-tracker-list');
    const userList = document.getElementById('user-tracker-list');

    aiList.innerHTML = '';
    userList.innerHTML = '';

    CARDS.forEach(card => {
      aiList.innerHTML += `<div class="tracker-item">
        <span>${card.name}</span>
        <strong>${game.aiHand[card.id]} 张</strong>
      </div>`;

      userList.innerHTML += `<div class="tracker-item">
        <span>${card.name}</span>
        <strong>${game.userHand[card.id]} 张</strong>
      </div>`;
    });
  }

  function updateSessionStats() {
    const stats = game.sessionStats;
    sessionWins.textContent = stats.wins;
    sessionLosses.textContent = stats.losses;
    sessionDraws.textContent = stats.draws;
    sessionGames.textContent = `${stats.games} 局`;
    const winRate = game.getSessionWinRate();
    sessionWinRate.textContent = winRate === null ? '—' : `${winRate}%`;
    gameoverSessionRecord.textContent =
      `本次游玩：${stats.wins} 胜 · ${stats.losses} 负 · ${stats.draws} 平`;
  }

  function checkGameOver() {
    if (game.userHp <= 0 || game.aiHp <= 0) {
      game.gameOver = true;
      const result = game.userHp > 0 && game.aiHp <= 0
        ? 'win'
        : (game.userHp <= 0 && game.aiHp > 0 ? 'loss' : 'draw');
      game.recordGameResult(result);
      updateSessionStats();
      setTimeout(() => {
        gameoverModal.classList.add('active');
        const title = document.getElementById('gameover-title');
        const desc = document.getElementById('gameover-desc');
        document.getElementById('stat-turns').textContent = game.turn;
        document.getElementById('stat-hp').textContent = game.userHp + ' HP';

        if (result === 'win') {
          title.textContent = '🏆 辩论压制，战斗胜利！';
          title.style.color = '#15803d';
          desc.textContent = `你凭借高超的词锋与手牌推演，成功击败了 ${selectedDiff.toUpperCase()} AI！`;
        } else if (result === 'loss') {
          title.textContent = '💀 辩词匮乏，遗憾战败！';
          title.style.color = '#b91c1c';
          desc.textContent = `AI 在残局中看破了你的手牌，你未能存活下来。`;
        } else {
          title.textContent = '🤝 同归于尽，双方平局！';
          title.style.color = '#d97706';
          desc.textContent = `双方辩手在最后一个回合同时耗尽了最后一口气。`;
        }
      }, 500);
    }
  }

  updateSessionStats();
  updateUI();
});
